<?php
$conexao = mysqli_connect("localhost", "root", "", "junior");
?>